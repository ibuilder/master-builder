# Changelog

All notable changes to the **master-builder** skill.

## [0.6.0] — 2026-07-25
Proves the "anywhere on Earth" claim with worked dossiers, and adds a document-intelligence discipline
distilled from studying open AEC-AI work by others (see Credits in the README).

### Added
- `references/jurisdiction-dossiers.md` — the unfamiliar-jurisdiction method **demonstrated**, not just
  described. Four dossiers, each teaching a different structural lesson: **England & Wales** (the
  regulator can be the schedule — Building Safety Act Gateway 2 running 25+ weeks against a 12-week
  target with ~45–50% rejection), **Dubai** (the AHJ depends on which plot you stand on — DM / DDA /
  Trakhees, with Civil Defence as a mandatory parallel track), **Australia** (published ≠ adopted — NCC
  2025 published 1 May 2026 but staggered to 2027 in several states), **Canada** (a model code has no
  force until a province enacts it; NBCC 2025 adds GHG as a formal objective). Plus a contributor template.
- `references/document-intelligence.md` — extracting trustworthy numbers from drawings, specs, change
  orders and pay apps: index-once/query-many, **confidence by provenance** (a schedule count and a
  pixel-scaled distance are not the same kind of fact), encoded sanity bounds, the
  **text-linearisation trap** (never trust a `$` column that survived PDF→text; recompute from
  quantity × rate), **coverage-aware findings** ("0 findings" is not a clean bill of health),
  spec↔drawing coordination joins, unit/designation canonicalization, non-destructive markup, and the
  deterministic-finding vs judgment-call split.

### Changed
- `global-codes.md` — **correction:** NCC 2025 and NBCC 2025 were treated as simply "current." Both are
  published-but-not-uniformly-adopted; the section now states the adoption reality and the trap.
- `construction-delivery.md` — added the owner-side **change-order pricing audit**: markup/O&P stacking,
  unit-price inflation, labor-rate padding, quantity tie-out.
- `pro-forma-review.md` — new §7 "Report what you could *not* check," applying the coverage-aware rule
  to model review.
- `digital-toolkit.md` — MCP connectors that drive the incumbent authoring tools (Revit, AutoCAD,
  Navisworks, Dynamo, Grasshopper); document-intelligence flagged as required reading for AI document workflows.
- SKILL.md — both new references wired into the protocol (step 1 and step 6) and the table;
  `description` extended to trigger on takeoff, spec cross-check, and change-order audit.
- README — a **Credits & related work** section.

## [0.5.0] — 2026-07-25
Content pass. Closes the one structural hole in the protocol and gives existing buildings the depth the
skill kept asserting they deserved.

### Added
- `references/risk-insurance.md` — **fills the only protocol step (7, Risk) that had no reference behind
  it.** The risk loop and the allocation principle (control *and* price *and* absorb — risk pushed onto a
  party that can't carry it isn't transferred, it's disguised), the risk register families, the contract
  clauses that actually fight (differing site conditions, EOT/concurrent delay, LDs, indemnity, waiver of
  subrogation), insurance products (builder's risk/CAR with DSU/ALOP, CGL, PI, wrap-ups, SDI), why a
  surety bond is credit rather than risk transfer, the 2026 market split (non-CAT rate relief vs ~12%
  CAT-zone increases; severe convective storm >$51bn US insured losses in 2025), **insurability as a
  feasibility variable**, and contingency as retained risk capital.
- `references/adaptive-reuse.md` — existing buildings on their own terms: why reuse now dominates
  (carbon + repriced basis + mandates), the physical screen that kills candidates fast (plate depth,
  floor-to-floor, structure, risers), the **IEBC 2024 compliance paths — prescriptive / work-area /
  performance — and the rule that you must pick one and not mix**, change-of-occupancy and work-area
  triggers, hazmat/structural/reality-capture due diligence, office-to-residential economics (record
  ~11.8M sf in 2025; only ~25–30% of buildings viable), building performance standards (NYC LL97 at
  $268/tCO₂e over cap, 50+ US jurisdictions, EU EPBD MEPS to class D by 2030/2033), and how underwriting
  a reuse deal differs.

### Changed
- SKILL.md — protocol step 7 now routes to `risk-insurance.md` and states the allocation principle;
  step 2 notes that with an existing building the order inverts (structure constrains program) and routes
  to `adaptive-reuse.md`; both added to the reference table; `description` extended to trigger on risk,
  insurance, surety, conversion, IEBC, and retrofit mandates.
- Reciprocal cross-links added from `development-lifecycle.md` (risk register, adaptive-reuse DD),
  `sustainability-carbon.md` (reuse hierarchy), and `construction-delivery.md` (contract risk clauses).

## [0.4.0] — 2026-07-24
Makes the skill callable as a tool by any MCP-capable agent, and holds the repo to the skill's own
build doctrine (staged validation, honest status, operational discipline).

### Added
- `scripts/mcp_server.py` — a **zero-dependency MCP server** (stdio) serving the protocol and the
  reference library as four read-only tools (`master_builder_get_protocol`, `_list_references`,
  `_read_reference`, `_search`) plus MCP *resources*. This restores **progressive disclosure** for
  non-Claude agents: they pull only the reference a task needs instead of the whole corpus. Stdlib-only
  Python 3.9+ — no SDK to install or pin (the official Python SDK is a `2.0.0b1` pre-release with a
  renamed API; per `build-doctrine.md` §4 the core must not depend on a moving part). Ships a
  22-check `--selftest`.
- `scripts/validate.py` — enforces the authoring rules CONTRIBUTING only stated: frontmatter shape,
  slug-form `name`, substantive `description`, lean SKILL.md, reference table ↔ files on disk both
  ways, and that every cross-reference resolves. `build-doctrine.md` §8 (compliance-as-code) applied
  to the skill itself.
- `.github/workflows/ci.yml` — on every push/PR (Python 3.9 + 3.12): validate the skill, self-test the
  MCP server, exercise it over **real stdio**, and fail if `dist/` has drifted from source.
- README — an MCP server section and a CI badge.

### Changed
- CONTRIBUTING — contributors run `validate.py` and the MCP self-test; the stdlib-only rule is explicit.

## [0.3.2] — 2026-07-23
Portability + reproducible build. The skill's knowledge now ships in a form any assistant can use, and
all distributables are generated from one source so they can't drift.

### Added
- `dist/master-builder.bundle.md` — a **one-file portable bundle** (the protocol + every reference,
  with setup notes) for use in ChatGPT, Gemini, Perplexity, or any API/model — not just Claude.
- `scripts/build.py` — one dependency-free build that regenerates `master-builder.skill`,
  `master-builder.zip`, and `master-builder.bundle.md` from `SKILL.md` + `references/`.
- README — a "Use it in other assistants" section (Custom GPT / Gem / Space / system-prompt recipes)
  and a note that `dist/` is generated by `python scripts/build.py`.

### Changed
- Packaging moved from an ad-hoc zip step to `scripts/build.py`; `dist/` is now generated, not hand-built.
- CONTRIBUTING — contributors rerun `python scripts/build.py` after edits.

## [0.3.1] — 2026-07-21
Reconciliation pass against the current Massing repo + research: adds climate **adaptation/resilience**
(the counterpart to carbon mitigation) and sharpens tool descriptions to the platform as it actually ships.

### Added
- `sustainability-carbon.md` §7 "Adaptation — the other half of climate" — design-to-future-hazard,
  resilience-as-underwriting (insurance/downtime/exit), and siting/passivity as the cheapest resilience.
- `global-codes.md` §4 — ASCE 24 flood-resistant design, Rational-Method stormwater sizing, and a
  forward-looking physical climate-risk overlay ("design to the future hazard, not just the historical map").
- SKILL.md — "The climate risk" added to the ground-in-place list; resilience/adaptation added to the
  `description` triggers and the reference-table summary.

### Changed
- `digital-toolkit.md` — reality-capture (2D→BIM raise, scan-to-BIM deviation, GIS/DEM overlays, LAS/LAZ),
  operations (CMMS, EUI, reserve study, UNIFORMAT II → Facility Condition Index, ESG Scope 1/2 + climate-risk
  rating), and AI/MCP (Claude skill pack; schedule-risk/carbon/permit-readiness engines off one model)
  updated to the current Massing capabilities; climate-resilience row added to the software map.
- README — "counts the carbon, the climate risk, and the power" reflects the resilience addition.

## [0.3.0] — 2026-07-21
Currency + decarbonization pass. Adds carbon as a first-class development discipline, refreshes code
editions to mid-2026, and folds in the power-constrained and tariff-driven cost environment.

### Added
- `references/sustainability-carbon.md` — whole-life & embodied carbon: the EN 15978 module map, the
  accounting standards (EN 15804 EPDs, RICS WLCA 2nd ed, ISO 14040/44), the 2026 regulatory teeth
  (EU CBAM definitive period, EPBD, Buy Clean, LEED v5 embodied-carbon prerequisite, ICC 2027 carbon
  focus), carbon-is-money (CBAM cost, green premium/brown discount, transition/stranded-asset risk),
  the reduction hierarchy, and a hotspot/cost-concentration method.

### Changed
- SKILL.md — ground-in-place rule now derives **power** (interconnection queue) and **carbon** from
  location; carbon reference added to the protocol and the reference table; carbon-boundary output
  convention added; `description` extended to trigger on carbon, decarbonization, and power/data-center questions.
- `global-codes.md` — utility-service gate sharpened to the 2026 power reality (~2,600 GW US
  interconnection queue, PJM 8-year application-to-operation, transformer 2–4-year lead); ICC 2027 and
  second-generation Eurocode timelines (definitive 2026 / publish 2027 / withdraw 2028) made concrete;
  carbon added to the energy/sustainability stack and the editions note.
- `digital-toolkit.md` — ISO 19650 second-generation revision (DIS 10 Mar 2026, BIM→IM, unified 9-step
  process, final 2027); 5D take-off feeds whole-life carbon; embodied-carbon row added to the software map.
- `construction-delivery.md` — 2025–26 escalation/tariff environment (Section 232 ~50% metals tariffs,
  ~8% aggregate escalation, price-escalation clauses) added to estimating; transformer/switchgear lead
  times added to long-leads.
- `real-estate-finance.md` — escalation/tariff and carbon (CBAM, green premium/brown discount,
  transition risk) added to the common-traps list.

## [0.2.0] — 2026-07-20
Enrichment pass after grounding on real projects and a live feasibility test (a retail-to-vertical-farm
development thesis and its pro-forma model).

### Added
- `references/build-doctrine.md` — cross-cutting engineering lessons distilled from real platforms
  (source-of-truth & stable identity, do heavy work at the right layer, open interchange, staged-
  validation gate, hard rails on irreversible actions, honest status, compliance-as-code).
- `references/pro-forma-review.md` — forensic model/deal review: reframe the asset, reconciliation pass,
  a defect checklist (NOI gross-up, dropped cost lines, non-cash in OpEx, zero-vacancy, unit errors),
  the three-questions test for assumptions, cost-concentration analysis, and validate-demand-before-capital.

### Changed
- SKILL.md protocol now leads program analysis with "name what the asset actually is" (reframe first).
- `global-codes.md` — utility interconnection / will-serve added as a schedule-and-cost gate for
  energy- and water-intensive uses and on-site generation.
- `digital-toolkit.md` and `construction-delivery.md` corrected to the verified architecture of the
  real repos (Massing on That Open Fragments + IfcOpenShell with GUID-stable server-side edit recipes,
  three pillars Model/Construction/Finance, code-intelligence pre-checks; gcPanel/ConstructAI on Next.js/TS).

## [0.1.0] — 2026-07-20
Initial release.

### Added
- SKILL.md — the Master Builder Protocol, ground-in-place rule, professional boundaries, output conventions.
- References: `global-codes.md`, `development-lifecycle.md`, `real-estate-finance.md`,
  `construction-delivery.md`, `digital-toolkit.md`.
