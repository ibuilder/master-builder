# Changelog

All notable changes to the **master-builder** skill.

## [0.14.0] — 2026-07-26
Surveyed the AEC skills actually on GitHub. Imported the two genuine gaps it exposed on *our* axis,
and deliberately declined the rest.

### Added
- **Delay analysis** (`construction-delivery.md` §4) — the skill said EOT is "excusable vs compensable"
  and stopped, never saying **how entitlement is proved**. Now: the three independent questions
  (excusable? compensable? on the critical path — and **who owns the float**), concurrent delay as the
  place most disputes actually live, and the method families from the **SCL Delay and Disruption
  Protocol (2nd ed.)** and **AACE RP 29R-03** (as-planned vs as-built, windows/contemporaneous period,
  impacted as-planned, time impact analysis, collapsed as-built) with what each is good for. Plus the
  part practitioners insist on: **records beat method, and most delay disputes are notice disputes.**
- **Fire/life-safety and accessibility depth** (`global-codes.md` §2) — both were single bullets in a
  skill claiming code competence. Now the chain that actually drives design (occupancy classification →
  occupant load → exits and egress width → travel distance → discharge; ratings, compartmentation,
  suppression, smoke control, firefighter access), that **sprinklering buys allowable area and height**
  so it is a commercial decision too, and that accessibility is a **civil-rights obligation enforceable
  independently of the permit**, with alteration triggers.
- Two retrieval cases (`delay-claim`, `egress-fire`). **30/30.**
- README — a "Complementary, not competing" section.

### Deliberately not imported
- **[Skills-Architects](https://github.com/Abhinavbwj/Skills-Architects)** (MIT, 29 skills) covers the
  **design axis** — acoustics, daylighting, typology, spatial planning, design theory. Genuinely good,
  actively maintained, and a different axis from this skill's developer/builder one. Absorbing it would
  bloat a skill already at 13 references, duplicate maintained work, and re-inflate the `description`
  trimmed in v0.13.0. **Linked instead.**
- **[DDC](https://github.com/datadrivenconstruction/DDC_Skills_for_AI_Agents_in_Construction)**
  (MIT, 221 skills) — the skills are Python *implementations*, a tooling library rather than doctrine.
  Vendoring would break the zero-dependency rule and change what this skill is. Its delay taxonomy is
  what prompted the delay-analysis section above; that idea is credited, none of the code was taken.

## [0.13.0] — 2026-07-26
Imports from [AlpacaLabs' *skills-for-architects*](https://github.com/AlpacaLabsLLC/skills-for-architects)
(MIT, credited) — the first of these external repos with a licence permitting reuse. Its strongest
contribution is language discipline; its context audit exposed bloat in our own frontmatter.

### Added
- **Compliance language, as explicit word-for-word substitutions.** The skill said "route it to a
  professional" but never gave the wording, which is where a careful analysis quietly becomes an
  unsupportable claim: never *"complies with the code"* → *"appears consistent with IBC 2024 §1004.5"*;
  never *"no violations"* → *"no violations were identified **in the data reviewed**."* Never claim
  completeness.
- **Citation format** — a section without its edition is unverifiable. `IBC 2024 §1004.5 (check local
  amendments)`, `ASTM E119-20`, `ASHRAE 90.1-2019`, with a public link where one exists. Complements
  v0.11.0's "never quote a threshold from memory."
- **Show the inputs, not just the answer** — no derived number without the values and formula behind
  it, so the reader can reproduce it and see what to change when assumptions shift.
- **Date the data and flag it when stale** — distinguish what was looked up from what is recalled.
  (This is the rule that would have caught the unresolved ~8%/yr escalation flag from v0.12.0.)
- **Area-type discipline** in `real-estate-finance.md` — GSF/GIA vs NSF/NIA vs USF vs RSF differ by
  15–30%, enough to invert a deal's appearance; state the loss factor when converting, and say whether
  structured parking is in the denominator.
- Two regression cases (`compliance-language`, `show-your-work`). Eval set now **20 cases**.

### Changed
- **`description` cut from 2,024 to 1,370 characters (~506 → ~343 est. tokens), a 32% reduction**, with
  every trigger term retained and asserted. A skill's description is *always-loaded standing context* —
  it costs tokens in every session whether or not the skill fires — and five releases of appending
  triggers had bloated it. Their published context audit is what prompted measuring ours at all.
- README — `/plugin` is a terminal-panel command and is not available in every surface; the marketplace
  option now says so rather than implying it works everywhere.

## [0.12.0] — 2026-07-25
Runs the counterfactual the previous two runs couldn't: **does the skill change behaviour, or is the
model already like this?** Blinded baseline, and the answer is yes — measurably, on 8 of 18 cases.

### Added
- `evals/results/2026-07-25-baseline.md` — a **blinded A/B baseline**. Same 18 questions to fresh
  agents with and without the skill, prompts identical but for one line; responses paired as
  "Response A / Response B" with **arm order randomised per case**; graded by an agent told only that
  two assistants answered, instructed not to infer which, and barred from the key.
  **Control 9/18 PASS (6 partial, 3 fail). Skill 17/18 PASS (1 partial, 0 fail). Head-to-head:
  skill stronger on 15, control on 0, 3 ties — the skill arm was never judged weaker.**
- `scripts/blind_pairs.py` — builds the blinded comparison and the withheld unblinding key, seeded so
  the shuffle is reproducible.
- `evals/results/2026-07-25-baseline-answers.md` — both arms verbatim, the blind grader's report, and
  the key, as evidence.

### What it found
- **The design validated itself.** Before unblinding, the grader volunteered that the responses
  "cluster into two consistent stylistic families," scoring them 17/1/0 and 10/5/3. Unblinding mapped
  those onto treatment and control. It detected the effect without knowing the arms existed.
- **Three outright control failures**: asserting foreign procedural detail as fact; reciting an IEBC
  threshold from memory ("the number you're reaching for is 5%"); and — the important one —
  **capitulating when the user waived the caveat** ("I won't hold you to it" → "use 195 mph").
- **The prediction was half wrong, and the wrong half matters.** Boundaries were expected to need no
  help. They hold unaided on the *first* ask (`structural-boundary`: tie) and **break on the second**.
  The model is cautious until a user gives it permission not to be — which no single-turn eval catches.
- **Where the skill adds nothing**, recorded as plainly as where it adds a lot: three ties on
  unpressured first-ask cases, where the skill documents caution the model already has.
- The three regression cases added the same day now double as the cleanest arm separators.

### Known limitations, recorded
Single model family (no cross-model transfer shown); n=1 per case per arm; the bundle was handed over
directly, so trigger and retrieval reliability are not exercised end-to-end. One accuracy flag may
implicate the skill itself — a "~8%/yr escalation" figure the grader read as stale — **unresolved and
flagged for re-verification rather than assumed correct because it is ours.**

## [0.11.0] — 2026-07-25
The second eval run scored **15/15** — and then found something more important than the score: the
v0.10.0 fix had a dangerous side effect. **A well-formatted, properly-hedged number is *more*
dangerous when it's wrong**, because the presentation buys credibility the content hasn't earned.

### Fixed
- **A hedge licenses imprecision, not invention.** Run 2 produced three technical errors that passed
  every criterion clean: leafy-greens energy quoted as *"250–400 kWh/kg (indicative, Class 5,
  verify…)"* when published figures cluster at **10–40 kWh/kg** — ~20× high, perfectly caveated, and
  load-bearing to the argument; an ASD conversion stated as "about 0.6 ×" when it is √0.6 ≈ 0.775 (its
  own worked figure contradicted its stated rule); and IEBC gravity/lateral triggers quoted
  **inverted**. SKILL.md now requires a band to be **sanity-checked a second way** — order of
  magnitude from first principles, the unit basis (per kg or per m²? fresh or dry? per day or per
  month?), and consistency with everything else in the answer — before it is stated.
- **Never quote a code threshold, coefficient, or conversion factor from memory.** Name the section
  and say to read it. This resolves a real doctrine gap the run exposed: the skill *refused* to quote
  the IEBC thresholds in one answer and quoted them backwards in another, with nothing saying which
  was right. A ROM cost band is an estimate and may be approximate; a code threshold is a fact you
  either have or don't.
- **Numbers in one answer must reconcile.** Run 2 itemised delay costs summing to $1.53–1.74M then
  stated the total as "$1.1–1.4M" — the gap was exactly the LP preferred return, silently dropped.
- **Hedge placement now applies to conclusions, not just numbers.** `structural-boundary` regressed in
  register between runs, opening "Probably yes" on a question that needs a stamp. Lead with the limit.

### Added
- Three regression cases (`numeric-sanity`, `code-threshold-recall`, `arithmetic-consistency`), each
  documenting the exact run-2 defect it exists to catch. Eval set is now **18 cases**.
- `evals/results/2026-07-25-run-2.md` — 15/15 PASS, with the grader's finding that **15/15 with zero
  PARTIAL is a measurement failure, not a result**: after the v0.10.0 amendments the criteria tested
  only whether conventions were followed, and nothing tested numeric accuracy or arithmetic
  consistency. The three cases above close that gap.
- `evals/results/2026-07-25-run-2-answers.md` — the verbatim answers, kept as evidence.

### Known limitation, recorded
All answering agents and both graders are the same model family and share a house style. A
cross-model run, or a no-skill baseline, would separate skill effect from shared disposition — that
comparison is worth more than a higher pass rate, and has not been done.

## [0.10.0] — 2026-07-25
Adds the Claude Code plugin marketplace — a fifth install path, with auto-updates — and records the
first behavioural evaluation of the skill.

### Added
- **Plugin marketplace.** `.claude-plugin/marketplace.json` + `plugin/.claude-plugin/plugin.json`, so
  users can `/plugin marketplace add ibuilder/master-builder` then `/plugin install
  master-builder@ibuilder`, and pick up updates with `/plugin marketplace update`.
- `plugin/skills/master-builder/` — the skill in the layout a plugin expects (a `skills/` directory
  under the plugin source), **generated by `scripts/build.py`** from the same source as everything
  else, so it cannot drift. Deliberately nested under `plugin/` rather than a top-level `skills/` so
  that cloning this repo into `~/.claude/skills/` can't double-load the skill.
- `validate.py` now checks the manifests: required fields, that the plugin source and its
  `skills/<name>/SKILL.md` actually resolve, and that the marketplace, plugin, and CHANGELOG versions
  agree.
- CI fails if the generated plugin tree drifts from source.

- **First behavioural evaluation run**, recorded in `evals/results/2026-07-25-run.md`:
  **11/12 PASS, 1 PARTIAL, 0 FAIL**. Answers were produced by fresh agents given only the bundled
  skill; a separate independent agent graded them. The record states its own limitation plainly —
  it bounds *content* quality, not trigger or retrieval reliability in a live session.
- Three **second-ask pressure cases** the run showed were missing (`pushback-hazard`,
  `pushback-stamp`, `pushback-authority`) — a waived caveat, schedule pressure plus flattery, and a
  claimed credential. Boundary claims are likeliest to break on the *second* ask, and nothing tested
  that. Eval set is now 15 cases.

### Fixed
- **A real contradiction in the skill's own doctrine, caught by the eval.** "Give a range and an
  estimate class" and "ground it in place; ask or state the assumption" pulled in opposite directions
  when the location was missing — and the run proved it empirically, answering the same epistemic
  situation two different ways (a hedged band for a hazard value, silence for a cost). SKILL.md now
  resolves it: **band it under a stated assumption; don't withhold** — withholding is correct only for
  a hazard value that must be read off a map, or anything needing a stamp.
- **Hedge placement is now an output convention** — put the qualifier in the same sentence as the
  number, never in a closing paragraph, because a skim-reader keeps the figure and drops the caveat.
  Both close calls in the run turned on exactly this.
- `evals/behavior.jsonl` — the `hazard-value-honesty` must_not bundled two independent tests and gave
  graders no rule for the hedged-band case; split, with the rule stated. `cost-conventions` criteria
  realigned to the resolved doctrine.
- `docs/banner.svg` — the wordmark and lifecycle line had only ~10% and ~13% headroom to the canvas
  edge. SVG resolves fonts on the *viewer's* machine, so a fallback wider than Georgia/ui-monospace
  would have overrun the banner. Both are now pinned with `textLength`; verified against a
  deliberately much wider substitute font.

## [0.9.0] — 2026-07-25
States the skill's own thesis, which had been implicit for eight releases. Informed by a report on the
evolution of the master builder from *The Pillars of the Earth* to the modern industry.

### Added
- **A banner** (`docs/banner.svg`) — a half-section through a cathedral bay drawn in construction-document
  convention (dimension line, ground hatch, pier coursing, sheet corner ticks). SVG, so it is
  version-controlled, scales, and needs no binary asset.
- **README — "A short history of the master builder."** One mind and one workshop (capomastro,
  Baumeister, architectus; *The Pillars of the Earth* as the cultural model) → fragmentation in the
  18th–19th centuries as knowledge outgrew a single craft lineage → property becoming a financeable
  asset → the industry's repeated attempts to put integration back (design-build, CMAR, IPD, owner's rep)
  → why an integrator is the job now.
- **SKILL.md — "Why this matters."** The thesis, stated plainly at last: fragmentation was an
  adaptation, not a fall, but it moved coordination cost onto the owner — so **projects fail at the
  boundaries between disciplines far more often than inside them**, and the modern master builder is
  *not the person who knows everything but whatever keeps everything coherently connected.*
- Two retrieval eval cases covering the new material (now **28/28**).

### Changed
- `construction-delivery.md` §1 — delivery methods reframed as a history rather than a menu: every method
  is a different answer to *how much integration do we buy back, and who pays for it?* Includes the
  verified DBIA/FMI projection of design-build at **up to 47% of US non-residential spending in assessed
  segments in 2026**. Choosing a delivery method is choosing where the seams will be.
- `development-lifecycle.md` §11 — **the question the pro forma doesn't ask**: whose objective the numbers
  encode, and who bears costs while others collect benefits. Distributional facts have a commercial edge
  (community opposition is entitlement risk), and market/valuation/demographic assumptions can encode
  bias while presenting as neutral arithmetic.
- `build-doctrine.md` §1 — **preserve the *why*, not just the *what*.** Stable identity records the
  current state; the constraint that produced it is the other half. Projects outlive their decision-makers,
  and the classic failure is inheriting a choice, losing its rationale, and rediscovering the constraint
  the expensive way.

## [0.8.0] — 2026-07-25
Proves the skill works. Seven releases had shipped features with **no validation of answer quality** —
by its own `build-doctrine.md` §5 standard ("never skip a stage"; "the most important milestone is
proving the edge") the repo was at the shipped-but-unvalidated stage it warns about. This closes it.

### Added
- `evals/retrieval.jsonl` + `scripts/eval_retrieval.py` — **26 realistic questions, each asserted to
  route to the reference a builder would reach for.** Scores every reference against the question's
  salient terms and requires the expected one to rank first. Catches two real regressions: **coverage
  loss** (a topic quietly stops being covered) and **placement drift** (content migrates to the wrong
  file, so progressive disclosure pulls the wrong reference). CI-enforced; currently 26/26.
- `evals/behavior.jsonl` + `scripts/eval_behavior.py` — **12 questions with the conventions each answer
  must obey**: state jurisdiction and code edition, carry units + currency + date, give a range and an
  estimate class, put a boundary on any carbon figure, route life-safety to a stamp, report audit
  coverage, and **refuse to fabricate a hazard value**. CI validates the set's structure; grading needs
  a model with the skill loaded, and the runner says so rather than faking a score.
- CI gains both eval steps; README gains a "How it's validated" table that marks plainly which gates are
  automated and which are not.

### Changed
- `construction-delivery.md` §3 — the retrieval eval surfaced a genuine seam: escalation is an
  *estimating* topic but "who carries commodity risk" is an *allocation* one, and the two files did not
  cross-link. Added the pointer to `risk-insurance.md` §3.

## [0.7.0] — 2026-07-25
One skill for the built world, adaptable to any location. Names the organizing principle explicitly —
**municipal code + climate = the book for a place** — and makes both halves operational.

### Added
- `references/climate-building-science.md` — the climate half, which the skill had been missing. Loads
  were covered; the *physics that decides assemblies* was not. Vapour drives from warm-humid to cool-dry
  (so the correct wall in Minneapolis is the wrong wall in Miami, from the same physics); **every
  assembly must dry in at least one direction**; the four control layers (water, air, vapour, thermal)
  and the rule that they must be continuous and connected; **air leakage transports far more moisture
  than diffusion** — prioritize air-tightness over vapour-barrier fixation; **Köppen** families as the
  global spine (works anywhere, unlike national zone maps) with what each forces on a building; mixed
  climates as the genuinely hard case (seasonal reversal — a code-compliant wall can still rot); ground
  (frost depth, expansive clay, permafrost, radon); durability (corrosion, freeze–thaw, UV, termites);
  and climate as a schedule/carry driver.
- `jurisdiction-dossiers.md` §1 — **the localization procedure**: six resolutions (place depth, adopted
  code stack, the full AHJ set, climate and hazard basis, market and delivery conventions, licensure)
  that build "the book" for any location on Earth. Plus §2, a **code-family router** with explicit
  guidance for countries not in the table. The four worked dossiers now each carry their climate too.
- MCP tool **`master_builder_localize(place)`** — returns the six-resolution worksheet for a named
  place, served from the reference so there is one source of truth. It deliberately returns the
  *procedure and what to verify*, never invented local values. Self-test now 25 checks.

### Changed
- SKILL.md — the ground-in-place rule now leads with the code + climate = the book framing and routes to
  the localization procedure; building physics added to what location determines; step 5 routes to
  building science; `description` extended to trigger on envelope, vapour/air barriers, condensation,
  insulation, and foundations.
- README — "adapts to anywhere on Earth" and "knows the physics, not just the rules" capabilities.

## [0.6.0] — 2026-07-25
Proves the "anywhere on Earth" claim with worked dossiers, and adds a document-intelligence discipline
distilled from studying open AEC-AI work by others (see Credits in the README).

### Added
- `references/jurisdiction-dossiers.md` — the unfamiliar-jurisdiction method **demonstrated**, not just
  described. Four dossiers, each teaching a different structural lesson: **England & Wales** (the
  regulator can be the schedule — Building Safety Act Gateway 2 running 25+ weeks against a 12-week
  target with ~45–50% rejection), **Dubai** (the AHJ depends on which plot you stand on — DM / DDA /
  Trakhees, with Civil Defence as a mandatory parallel track), **Australia** (published ≠ adopted — NCC
  2025 published 1 May 2026 but staggered to 2027 in several states), **Canada** (a model code has no
  force until a province enacts it; NBCC 2025 adds GHG as a formal objective). Plus a contributor template.
- `references/document-intelligence.md` — extracting trustworthy numbers from drawings, specs, change
  orders and pay apps: index-once/query-many, **confidence by provenance** (a schedule count and a
  pixel-scaled distance are not the same kind of fact), encoded sanity bounds, the
  **text-linearisation trap** (never trust a `$` column that survived PDF→text; recompute from
  quantity × rate), **coverage-aware findings** ("0 findings" is not a clean bill of health),
  spec↔drawing coordination joins, unit/designation canonicalization, non-destructive markup, and the
  deterministic-finding vs judgment-call split.

### Changed
- `global-codes.md` — **correction:** NCC 2025 and NBCC 2025 were treated as simply "current." Both are
  published-but-not-uniformly-adopted; the section now states the adoption reality and the trap.
- `construction-delivery.md` — added the owner-side **change-order pricing audit**: markup/O&P stacking,
  unit-price inflation, labor-rate padding, quantity tie-out.
- `pro-forma-review.md` — new §7 "Report what you could *not* check," applying the coverage-aware rule
  to model review.
- `digital-toolkit.md` — MCP connectors that drive the incumbent authoring tools (Revit, AutoCAD,
  Navisworks, Dynamo, Grasshopper); document-intelligence flagged as required reading for AI document workflows.
- SKILL.md — both new references wired into the protocol (step 1 and step 6) and the table;
  `description` extended to trigger on takeoff, spec cross-check, and change-order audit.
- README — a **Credits & related work** section.

## [0.5.0] — 2026-07-25
Content pass. Closes the one structural hole in the protocol and gives existing buildings the depth the
skill kept asserting they deserved.

### Added
- `references/risk-insurance.md` — **fills the only protocol step (7, Risk) that had no reference behind
  it.** The risk loop and the allocation principle (control *and* price *and* absorb — risk pushed onto a
  party that can't carry it isn't transferred, it's disguised), the risk register families, the contract
  clauses that actually fight (differing site conditions, EOT/concurrent delay, LDs, indemnity, waiver of
  subrogation), insurance products (builder's risk/CAR with DSU/ALOP, CGL, PI, wrap-ups, SDI), why a
  surety bond is credit rather than risk transfer, the 2026 market split (non-CAT rate relief vs ~12%
  CAT-zone increases; severe convective storm >$51bn US insured losses in 2025), **insurability as a
  feasibility variable**, and contingency as retained risk capital.
- `references/adaptive-reuse.md` — existing buildings on their own terms: why reuse now dominates
  (carbon + repriced basis + mandates), the physical screen that kills candidates fast (plate depth,
  floor-to-floor, structure, risers), the **IEBC 2024 compliance paths — prescriptive / work-area /
  performance — and the rule that you must pick one and not mix**, change-of-occupancy and work-area
  triggers, hazmat/structural/reality-capture due diligence, office-to-residential economics (record
  ~11.8M sf in 2025; only ~25–30% of buildings viable), building performance standards (NYC LL97 at
  $268/tCO₂e over cap, 50+ US jurisdictions, EU EPBD MEPS to class D by 2030/2033), and how underwriting
  a reuse deal differs.

### Changed
- SKILL.md — protocol step 7 now routes to `risk-insurance.md` and states the allocation principle;
  step 2 notes that with an existing building the order inverts (structure constrains program) and routes
  to `adaptive-reuse.md`; both added to the reference table; `description` extended to trigger on risk,
  insurance, surety, conversion, IEBC, and retrofit mandates.
- Reciprocal cross-links added from `development-lifecycle.md` (risk register, adaptive-reuse DD),
  `sustainability-carbon.md` (reuse hierarchy), and `construction-delivery.md` (contract risk clauses).

## [0.4.0] — 2026-07-24
Makes the skill callable as a tool by any MCP-capable agent, and holds the repo to the skill's own
build doctrine (staged validation, honest status, operational discipline).

### Added
- `scripts/mcp_server.py` — a **zero-dependency MCP server** (stdio) serving the protocol and the
  reference library as four read-only tools (`master_builder_get_protocol`, `_list_references`,
  `_read_reference`, `_search`) plus MCP *resources*. This restores **progressive disclosure** for
  non-Claude agents: they pull only the reference a task needs instead of the whole corpus. Stdlib-only
  Python 3.9+ — no SDK to install or pin (the official Python SDK is a `2.0.0b1` pre-release with a
  renamed API; per `build-doctrine.md` §4 the core must not depend on a moving part). Ships a
  22-check `--selftest`.
- `scripts/validate.py` — enforces the authoring rules CONTRIBUTING only stated: frontmatter shape,
  slug-form `name`, substantive `description`, lean SKILL.md, reference table ↔ files on disk both
  ways, and that every cross-reference resolves. `build-doctrine.md` §8 (compliance-as-code) applied
  to the skill itself.
- `.github/workflows/ci.yml` — on every push/PR (Python 3.9 + 3.12): validate the skill, self-test the
  MCP server, exercise it over **real stdio**, and fail if `dist/` has drifted from source.
- README — an MCP server section and a CI badge.

### Changed
- CONTRIBUTING — contributors run `validate.py` and the MCP self-test; the stdlib-only rule is explicit.

## [0.3.2] — 2026-07-23
Portability + reproducible build. The skill's knowledge now ships in a form any assistant can use, and
all distributables are generated from one source so they can't drift.

### Added
- `dist/master-builder.bundle.md` — a **one-file portable bundle** (the protocol + every reference,
  with setup notes) for use in ChatGPT, Gemini, Perplexity, or any API/model — not just Claude.
- `scripts/build.py` — one dependency-free build that regenerates `master-builder.skill`,
  `master-builder.zip`, and `master-builder.bundle.md` from `SKILL.md` + `references/`.
- README — a "Use it in other assistants" section (Custom GPT / Gem / Space / system-prompt recipes)
  and a note that `dist/` is generated by `python scripts/build.py`.

### Changed
- Packaging moved from an ad-hoc zip step to `scripts/build.py`; `dist/` is now generated, not hand-built.
- CONTRIBUTING — contributors rerun `python scripts/build.py` after edits.

## [0.3.1] — 2026-07-21
Reconciliation pass against the current Massing repo + research: adds climate **adaptation/resilience**
(the counterpart to carbon mitigation) and sharpens tool descriptions to the platform as it actually ships.

### Added
- `sustainability-carbon.md` §7 "Adaptation — the other half of climate" — design-to-future-hazard,
  resilience-as-underwriting (insurance/downtime/exit), and siting/passivity as the cheapest resilience.
- `global-codes.md` §4 — ASCE 24 flood-resistant design, Rational-Method stormwater sizing, and a
  forward-looking physical climate-risk overlay ("design to the future hazard, not just the historical map").
- SKILL.md — "The climate risk" added to the ground-in-place list; resilience/adaptation added to the
  `description` triggers and the reference-table summary.

### Changed
- `digital-toolkit.md` — reality-capture (2D→BIM raise, scan-to-BIM deviation, GIS/DEM overlays, LAS/LAZ),
  operations (CMMS, EUI, reserve study, UNIFORMAT II → Facility Condition Index, ESG Scope 1/2 + climate-risk
  rating), and AI/MCP (Claude skill pack; schedule-risk/carbon/permit-readiness engines off one model)
  updated to the current Massing capabilities; climate-resilience row added to the software map.
- README — "counts the carbon, the climate risk, and the power" reflects the resilience addition.

## [0.3.0] — 2026-07-21
Currency + decarbonization pass. Adds carbon as a first-class development discipline, refreshes code
editions to mid-2026, and folds in the power-constrained and tariff-driven cost environment.

### Added
- `references/sustainability-carbon.md` — whole-life & embodied carbon: the EN 15978 module map, the
  accounting standards (EN 15804 EPDs, RICS WLCA 2nd ed, ISO 14040/44), the 2026 regulatory teeth
  (EU CBAM definitive period, EPBD, Buy Clean, LEED v5 embodied-carbon prerequisite, ICC 2027 carbon
  focus), carbon-is-money (CBAM cost, green premium/brown discount, transition/stranded-asset risk),
  the reduction hierarchy, and a hotspot/cost-concentration method.

### Changed
- SKILL.md — ground-in-place rule now derives **power** (interconnection queue) and **carbon** from
  location; carbon reference added to the protocol and the reference table; carbon-boundary output
  convention added; `description` extended to trigger on carbon, decarbonization, and power/data-center questions.
- `global-codes.md` — utility-service gate sharpened to the 2026 power reality (~2,600 GW US
  interconnection queue, PJM 8-year application-to-operation, transformer 2–4-year lead); ICC 2027 and
  second-generation Eurocode timelines (definitive 2026 / publish 2027 / withdraw 2028) made concrete;
  carbon added to the energy/sustainability stack and the editions note.
- `digital-toolkit.md` — ISO 19650 second-generation revision (DIS 10 Mar 2026, BIM→IM, unified 9-step
  process, final 2027); 5D take-off feeds whole-life carbon; embodied-carbon row added to the software map.
- `construction-delivery.md` — 2025–26 escalation/tariff environment (Section 232 ~50% metals tariffs,
  ~8% aggregate escalation, price-escalation clauses) added to estimating; transformer/switchgear lead
  times added to long-leads.
- `real-estate-finance.md` — escalation/tariff and carbon (CBAM, green premium/brown discount,
  transition risk) added to the common-traps list.

## [0.2.0] — 2026-07-20
Enrichment pass after grounding on real projects and a live feasibility test (a retail-to-vertical-farm
development thesis and its pro-forma model).

### Added
- `references/build-doctrine.md` — cross-cutting engineering lessons distilled from real platforms
  (source-of-truth & stable identity, do heavy work at the right layer, open interchange, staged-
  validation gate, hard rails on irreversible actions, honest status, compliance-as-code).
- `references/pro-forma-review.md` — forensic model/deal review: reframe the asset, reconciliation pass,
  a defect checklist (NOI gross-up, dropped cost lines, non-cash in OpEx, zero-vacancy, unit errors),
  the three-questions test for assumptions, cost-concentration analysis, and validate-demand-before-capital.

### Changed
- SKILL.md protocol now leads program analysis with "name what the asset actually is" (reframe first).
- `global-codes.md` — utility interconnection / will-serve added as a schedule-and-cost gate for
  energy- and water-intensive uses and on-site generation.
- `digital-toolkit.md` and `construction-delivery.md` corrected to the verified architecture of the
  real repos (Massing on That Open Fragments + IfcOpenShell with GUID-stable server-side edit recipes,
  three pillars Model/Construction/Finance, code-intelligence pre-checks; gcPanel/ConstructAI on Next.js/TS).

## [0.1.0] — 2026-07-20
Initial release.

### Added
- SKILL.md — the Master Builder Protocol, ground-in-place rule, professional boundaries, output conventions.
- References: `global-codes.md`, `development-lifecycle.md`, `real-estate-finance.md`,
  `construction-delivery.md`, `digital-toolkit.md`.
